<?php

echo "Привет, Otus!<br>".date("Y-m-d H:i:s");

phpinfo();