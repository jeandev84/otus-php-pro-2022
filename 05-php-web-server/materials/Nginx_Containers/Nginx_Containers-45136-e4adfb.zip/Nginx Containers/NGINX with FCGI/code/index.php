<?php

echo "Привет, SkillFactory!<br>".date("Y-m-d H:i:s") ."<br><br>";

echo "Что-то новое";

phpinfo();